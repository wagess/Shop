<?php
/**
 * Plugin Name: WP/LR IPTC Keywords API v3
 * Description: Récupère les mots-clés depuis WordPress meta (synchronisés par WP/LR)
 * Version: 3.0
 */

// CORS — autoriser le shop
add_action('rest_api_init', function () {
    remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
    add_filter('rest_pre_serve_request', function ($value) {
        $allowed = 'https://shop.stephanewagner.com';
        $origin  = $_SERVER['HTTP_ORIGIN'] ?? '';
        if ($origin === $allowed) {
            header("Access-Control-Allow-Origin: {$allowed}");
            header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
            header('Access-Control-Allow-Headers: Content-Type, Authorization');
            header('Access-Control-Allow-Credentials: true');
        }
        return $value;
    });
}, 15);

// Répondre aux preflight OPTIONS
add_action('init', function () {
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        $allowed = 'https://shop.stephanewagner.com';
        $origin  = $_SERVER['HTTP_ORIGIN'] ?? '';
        if ($origin === $allowed) {
            header("Access-Control-Allow-Origin: {$allowed}");
            header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
            header('Access-Control-Allow-Headers: Content-Type, Authorization');
            http_response_code(204);
            exit;
        }
    }
});

// Fonction utilitaire pour décoder les entités HTML - version CORRIGÉE
function decode_html_entities_recursive($data) {
    if (is_array($data)) {
        return array_map('decode_html_entities_recursive', $data);
    } elseif (is_string($data)) {
        $s = $data;

        // 1. Décodage des entités HTML nommées ET numériques
        for ($i = 0; $i < 3; $i++) {
            $decoded = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($decoded === $s) break;
            $s = $decoded;
        }
        
        // 2. Décodage FORCE de toutes les entités numériques résiduelles
        // Ceci gère &#8217;, &#39;', etc.
        // Gérer le double-encodage (ex: &amp;#8217; au lieu de &#8217;)
        $s = str_replace('&amp;#', '&#', $s);
        $s = preg_replace_callback('/&#([0-9]+);/u', function($matches) {
            return mb_chr((int)$matches[1], 'UTF-8');
        }, $s);
        
        // Gérer aussi les entités hexadécimales &#x2019; etc.
        $s = preg_replace_callback('/&#x([0-9a-fA-F]+);/u', function($matches) {
            return mb_chr(hexdec($matches[1]), 'UTF-8');
        }, $s);

        // 3. Normaliser toutes les variantes d'apostrophes en apostrophe ASCII simple
        $apostrophes = array(
            "\u{2018}" => "'",  // U+2018 LEFT SINGLE QUOTATION MARK
            "\u{2019}" => "'",  // U+2019 RIGHT SINGLE QUOTATION MARK (&#8217;)
            "\u{00B4}" => "'",  // ACUTE ACCENT
            "`" => "'",  // GRAVE ACCENT
            "\u{02B9}" => "'",  // MODIFIER LETTER PRIME
            "\u{02BB}" => "'",  // MODIFIER LETTER TURNED COMMA
            "\u{02BC}" => "'",  // MODIFIER LETTER APOSTROPHE
            "\u{02BD}" => "'",  // MODIFIER LETTER REVERSED COMMA
            "\u{02BE}" => "'",  // MODIFIER LETTER RIGHT HALF RING
            "\u{02CA}" => "'",  // MODIFIER LETTER ACUTE ACCENT
            "\u{02CB}" => "'",  // MODIFIER LETTER GRAVE ACCENT
            "\u{2032}" => "'",  // PRIME
            "\u{201A}" => "'",  // SINGLE LOW-9 QUOTATION MARK
            "\u{201B}" => "'",  // SINGLE HIGH-REVERSED-9 QUOTATION MARK
        );
        $s = strtr($s, $apostrophes);

        // 4. Remplacer les guillemets typographiques et tirets
        $map = array(
            '"' => '"', // U+201C
            '"' => '"', // U+201D
            '„' => '"', // DOUBLE LOW-9
            '‟' => '"', // DOUBLE HIGH-REVERSED-9
            '–' => '-', // EN DASH
            '—' => '-', // EM DASH
        );
        $s = strtr($s, $map);

        // 5. Remplacer les espaces insécables par des espaces normaux
        $s = str_replace("\xC2\xA0", ' ', $s); // UTF-8 non-breaking space
        $s = str_replace("\u{00A0}", ' ', $s); // Unicode notation
        $s = preg_replace('/\h/u', ' ', $s); // Tous les espaces horizontaux

        return trim($s);
    }
    return $data;
}

// Fonction pour normaliser les accents et caractères spéciaux
function normalize_search_string($string) {
    if (empty($string)) return '';
    
    // D'abord décoder les entités HTML
    $string = decode_html_entities_recursive($string);
    
    // Normaliser les accents
    $accents = array(
        'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
        'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e',
        'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i',
        'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o',
        'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ü' => 'u',
        'ç' => 'c', 'ñ' => 'n',
        'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A', 'Å' => 'A',
        'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
        'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I',
        'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O',
        'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U',
        'Ç' => 'C', 'Ñ' => 'N'
    );
    
    return strtolower(strtr($string, $accents));
}

add_action('rest_api_init', function () {
    // Endpoint commande impression
    register_rest_route('wplr-iptc/v1', '/send-order', array(
        'methods' => 'POST',
        'callback' => 'send_print_order',
        'permission_callback' => '__return_true',
    ));

    // Endpoint pour les keywords
    register_rest_route('wplr-iptc/v1', '/media/(?P<id>\d+)/keywords', array(
        'methods' => 'GET',
        'callback' => 'get_keywords_from_wp_meta',
        'permission_callback' => '__return_true',
        'args' => array(
            'profile' => array(
            )
        )
    ));

    // Endpoint pour image aléatoire
    register_rest_route('wplr-iptc/v1', '/random-image', array(
        'methods' => 'GET',
        'callback' => 'get_random_image',
        'permission_callback' => '__return_true',
        'args' => array(
            'size' => array(
            )
        )
    ));

    // Endpoint de recherche par mot-clé
    register_rest_route('wplr-iptc/v1', '/search/(?P<keyword>[^/]+)', array(
        'methods' => 'GET',
        'callback' => 'search_photos_by_keyword',
        'permission_callback' => '__return_true'
    ));
});

function get_keywords_from_wp_meta($request) {
    $media_id = $request['id'];
    $profile = $request->get_param('profile') ?: 'default';
    $keywords = array();
    $debug = array();
    
    $debug['profile_received'] = $profile;
    $debug['request_params'] = $request->get_params();
    
    // Vérifier que le média existe
    $post = get_post($media_id);
    if (!$post || $post->post_type !== 'attachment') {
        return new WP_Error('invalid_media', 'ID de média invalide', array('status' => 404));
    }
    
    // Récupérer les métadonnées de l'image
    $attachment_meta = wp_get_attachment_metadata($media_id);
    $debug['has_meta'] = !empty($attachment_meta);
    
    // 1. Essayer depuis image_meta->keywords (synchronisé par WP/LR)
    if (isset($attachment_meta['image_meta']['keywords']) && is_array($attachment_meta['image_meta']['keywords']) && !empty($attachment_meta['image_meta']['keywords'])) {
        $keywords = decode_html_entities_recursive($attachment_meta['image_meta']['keywords']);
        $debug['keywords_source'] = 'image_meta (WP/LR sync)';
        $debug['html_decoded'] = 'image_meta';
    }
    
    // 1.5 Si vide, essayer depuis wp_7uz9wu_lrsync_meta
    if (empty($keywords)) {
        global $wpdb;
        $lrsync_keywords = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM wp_7uz9wu_lrsync_meta 
             LIMIT 1",
            $media_id
        ));
        
        if ($lrsync_keywords) {
            // Peut être sérialisé PHP ou CSV
            $parsed = @unserialize($lrsync_keywords);
            if ($parsed && is_array($parsed)) {
                $debug['html_decoded'] = 'lrsync_unserialized';
            } else {
                // Essayer CSV
                $csv_keywords = array_map('trim', explode(',', $lrsync_keywords));
                $keywords = decode_html_entities_recursive(array_filter($csv_keywords));
                $debug['keywords_source'] = 'wp_lrsync_meta (CSV)';
                $debug['html_decoded'] = 'lrsync_csv';
            }
        }
    }
    
    // 2. Si vide et profile=aiptc, lire IPTC directement depuis le fichier
    if (empty($keywords) && $profile === 'aiptc') {
        $file_path = get_attached_file($media_id);
        $debug['file_path'] = $file_path;
        
        if ($file_path && file_exists($file_path)) {
            // Si c'est un .webp, chercher le .jpg original
            if (preg_match('/\.webp$/i', $file_path)) {
                $original_path = preg_replace('/\.webp$/i', '.jpg', $file_path);
                if (file_exists($original_path)) {
                    $file_path = $original_path;
                    $debug['switched_to_original'] = $original_path;
                }
            }
            
            // Lire IPTC depuis le fichier
            $size = getimagesize($file_path, $info);
            if (isset($info['APP13'])) {
                $iptc = iptcparse($info['APP13']);
                $debug['iptc_raw'] = $iptc;
                
                // Keywords IPTC = 2#025
                if (isset($iptc['2#025'])) {
                    $keywords = decode_html_entities_recursive($iptc['2#025']);
                    $debug['keywords_source'] = 'IPTC direct from file';
                    $debug['html_decoded'] = 'iptc_direct';
                }
            } else {
                $debug['no_iptc_in_file'] = true;
            }
        }
    }
    
    // Récupérer le titre et le décoder
    $title = '';
    if (isset($attachment_meta['image_meta']['title'])) {
        $title = decode_html_entities_recursive($attachment_meta['image_meta']['title']);
    }
    
    // EXIF
    $exif_data = array();
    if (isset($attachment_meta['image_meta'])) {
        $image_meta = $attachment_meta['image_meta'];
        if (!empty($image_meta['camera'])) $exif_data['camera'] = $image_meta['camera'];
        if (!empty($image_meta['aperture'])) $exif_data['aperture'] = $image_meta['aperture'];
        if (!empty($image_meta['iso'])) $exif_data['iso'] = $image_meta['iso'];
        if (!empty($image_meta['focal_length'])) $exif_data['focal_length'] = $image_meta['focal_length'];
        if (!empty($image_meta['shutter_speed'])) $exif_data['shutter_speed'] = $image_meta['shutter_speed'];
    }
    
    // Backup : tags WordPress
    $wp_tags = wp_get_post_terms($media_id, 'post_tag', array('fields' => 'names'));
    if (!is_wp_error($wp_tags) && !empty($wp_tags)) {
        $decoded_tags = decode_html_entities_recursive($wp_tags);
        foreach ($decoded_tags as $tag) {
            if (!in_array($tag, $keywords)) {
                $keywords[] = $tag;
            }
        }
        $debug['wp_tags_added'] = count($wp_tags);
        $debug['html_decoded_tags'] = true;
    }
    
    // Nettoyer et s'assurer que tout est décodé une dernière fois
    $keywords = decode_html_entities_recursive($keywords);
    $keywords = array_unique($keywords);
    $keywords = array_filter($keywords, function($k) { return !empty(trim($k)); });
    $keywords = array_map('trim', $keywords);
    $keywords = array_values($keywords);
    
    return array(
        'media_id' => $media_id,
        'keywords' => $keywords,
        'count' => count($keywords),
        'title' => $title,
        'exif' => $exif_data,
        'source' => 'wp_attachment_metadata + IPTC fallback',
        'profile' => $profile,
        'debug' => $debug
    );
}

function send_print_order($request) {
    $params = $request->get_json_params();

    $name        = sanitize_text_field($params['name'] ?? '');
    $email       = sanitize_email($params['email'] ?? '');
    $phone       = sanitize_text_field($params['phone'] ?? '');
    $format      = sanitize_text_field($params['format'] ?? '');
    $paper       = sanitize_text_field($params['paper'] ?? '');
    $message     = sanitize_textarea_field($params['message'] ?? '');
    $photo_title = sanitize_text_field($params['photo_title'] ?? '');
    $photo_id    = intval($params['photo_id'] ?? 0);
    $photo_url   = esc_url_raw($params['photo_url'] ?? '');

    if (empty($name) || empty($email)) {
        return new WP_Error('missing_fields', 'Nom et courriel requis.', array('status' => 400));
    }
    if (!is_email($email)) {
        return new WP_Error('invalid_email', 'Adresse courriel invalide.', array('status' => 400));
    }

    $to      = 'info@stephanewagner.com';
    $subject = "Commande d'impression : {$photo_title}";
    $body    = "Nouvelle commande d'impression\n";
    $body   .= str_repeat('-', 40) . "\n\n";
    $body   .= "Photo      : {$photo_title} (ID : {$photo_id})\n";
    $body   .= "URL        : {$photo_url}\n\n";
    $body   .= "Client\n";
    $body   .= "Nom        : {$name}\n";
    $body   .= "Courriel   : {$email}\n";
    if ($phone) $body .= "Téléphone  : {$phone}\n";
    $body   .= "\nDétails de la commande\n";
    $body   .= "Format     : {$format}\n";
    $body   .= "Papier     : {$paper}\n";
    if ($message) $body .= "\nMessage :\n{$message}\n";

    $headers = array(
        'Content-Type: text/plain; charset=UTF-8',
        "Reply-To: {$name} <{$email}>",
    );

    $sent = wp_mail($to, $subject, $body, $headers);

    if (!$sent) {
        return new WP_Error('mail_failed', "Échec de l'envoi du courriel.", array('status' => 500));
    }

    return array('success' => true);
}

// Nouvelle fonction pour image aléatoire
function get_random_image($request) {
    $size = $request->get_param('size') ?: 'large';
    
    // Récupérer une image aléatoire directement via SQL
    $attachments = get_posts(array(
        'post_type' => 'attachment',
        'post_mime_type' => 'image',
        'post_status' => 'inherit',
        'posts_per_page' => 1,  // réduit de -1 à 1
        'orderby' => 'rand',
        'meta_query' => array(
        )
    ));
    
    if (empty($attachments)) {
        return new WP_Error('no_images', 'Aucune image trouvée', array('status' => 404));
    }
    
    $random_attachment = $attachments[0];
    $attachment_id = $random_attachment->ID;
    
    // Récupérer les différentes tailles d'images
    $image_urls = array();
    $sizes = array('thumbnail', 'medium', 'large', 'full');
    
    foreach ($sizes as $img_size) {
        $image_data = wp_get_attachment_image_src($attachment_id, $img_size);
        if ($image_data) {
            $image_urls[$img_size] = array(
                'url' => $image_data[0],
                'width' => $image_data[1],
                'height' => $image_data[2]
            );
        }
    }
    
    // URL principale selon la taille demandée
    $main_image = wp_get_attachment_image_src($attachment_id, $size);
    $main_url = $main_image ? $main_image[0] : '';
    
    // Métadonnées
    $attachment_meta = wp_get_attachment_metadata($attachment_id);
    $title = decode_html_entities_recursive(get_the_title($attachment_id));
    $alt_text = decode_html_entities_recursive(get_post_meta($attachment_id, '_wp_attachment_image_alt', true));
    
    // Collection/Album (si vous utilisez un plugin de galerie)
    $collection_name = '';
    $terms = wp_get_post_terms($attachment_id, 'media_category');
    if (!is_wp_error($terms) && !empty($terms)) {
        $collection_name = decode_html_entities_recursive($terms[0]->name);
    }
    
    return array(
        'id' => $attachment_id,
        'url' => $main_url,
        'urls' => $image_urls,
        'title' => $title,
        'alt' => $alt_text,
        'collection' => $collection_name,
        'width' => $main_image[1] ?? 0,
        'height' => $main_image[2] ?? 0,
        'file_size' => file_exists(get_attached_file($attachment_id)) ? filesize(get_attached_file($attachment_id)) : 0,
        'mime_type' => get_post_mime_type($attachment_id),
        'timestamp' => time()
    );
}

function search_photos_by_keyword($request) {
    $keyword = sanitize_text_field($request['keyword']);
    $keyword = urldecode($keyword);
    $keyword = decode_html_entities_recursive($keyword); // Décoder la recherche aussi
    
    $normalized_keyword = normalize_search_string($keyword);

    global $wpdb;
    
    // Chercher directement dans wp_7uz9wu_lrsync_meta
    $sql = "
        SELECT DISTINCT lm.post_id, lm.meta_value as keywords_raw
        FROM wp_7uz9wu_lrsync_meta lm
        INNER JOIN {$wpdb->posts} p ON lm.post_id = p.ID
        WHERE lm.meta_key = 'keywords'
        AND p.post_type = 'attachment'
        AND p.post_status = 'inherit'
        AND lm.meta_value IS NOT NULL
        AND lm.meta_value != ''
    ";
    
    $keyword_entries = $wpdb->get_results($sql);
    
    $results = array();
    
    foreach ($keyword_entries as $entry) {
        $post_id = $entry->post_id;
        $keywords_raw = $entry->keywords_raw;
        
        // Parser les mots-clés (sérialisé ou CSV)
        $all_keywords = array();
        
        // Essayer unserialized
        $parsed = @unserialize($keywords_raw);
        if ($parsed && is_array($parsed)) {
            $all_keywords = decode_html_entities_recursive($parsed);
        } else {
            // Essayer CSV
            $csv_keywords = array_map('trim', explode(',', $keywords_raw));
            $all_keywords = decode_html_entities_recursive(array_filter($csv_keywords));
        }
        
        if (empty($all_keywords)) {
            continue;
        }
        
        // Vérifier si le mot-clé correspond
        $keyword_found = false;
        $matching_keywords = array();
        
        foreach ($all_keywords as $kw) {
            if (empty(trim($kw))) continue;
            
            $normalized_kw = normalize_search_string($kw);
            if (strpos($normalized_kw, $normalized_keyword) !== false) {
                $keyword_found = true;
                $matching_keywords[] = $kw;
            }
        }
        
        if ($keyword_found) {
            $image_url = wp_get_attachment_image_url($post_id, 'large');
            $thumbnail_url = wp_get_attachment_image_url($post_id, 'medium');
            $title = decode_html_entities_recursive(get_the_title($post_id)); // Décoder le titre aussi
            
            if ($image_url) {
                $results[] = array(
                    'id' => $post_id,
                    'title' => $title ?: 'Image #' . $post_id,
                    'url' => $image_url,
                    'thumbnail_url' => $thumbnail_url ?: $image_url,
                    'keywords' => array_values(array_unique($all_keywords)),
                    'matching_keywords' => array_values(array_unique($matching_keywords))
                );
            }
        }
    }
    
    return rest_ensure_response(array(
        'results' => $results,
        'total' => count($results),
        'query' => $keyword,
        'normalized_query' => $normalized_keyword,
        'debug' => array(
        )
    ));
}